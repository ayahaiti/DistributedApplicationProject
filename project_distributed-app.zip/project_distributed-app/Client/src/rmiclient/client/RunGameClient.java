package rmiclient.client;

import rmiclient.services.IGame;

import java.rmi.Naming;

public class RunGameClient {

}
