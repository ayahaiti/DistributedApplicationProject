package cote_serveur;

import java.net.InetAddress;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Classeinstanciation {

    //A noter que le registre RMI doit s'exécuter avant de pouvoir enregistrer un objet ou obtenir une référence
    // ce lancement ne doit avoir lieu qu'une seule fois
    public static void main(String[] args) {

        //le security manager
        try{
            LocateRegistry.createRegistry(1099); //port

            System.out.println("Mise en place du security Manager ...");
        //l'instanciation d'un objet distant
            InformationImpl informationImpl = new InformationImpl();

            System.setProperty("java.security.policy","src/security.policy");

        //Enregistrer l'objet créé dans le registre de noms en lui affectant un nom
        //nom = url (url sous la forme [rmi:// + nom du serveur + nom associé à l'objet
        //c'est cet URL que les clients vont appeler pour obtenir une référence sur l'objet distant
            String url = "rmi://" + InetAddress.getLocalHost().getHostAddress() + "/Classeinstanciation";//192.168.1.73

        //l'enregistrement
            System.out.println("Enregistrement de l'objet avec l'url : " + url);
            Naming.rebind(url, informationImpl);

            System.out.println("Serveur lancé");
        } catch (Exception e){
            e.printStackTrace();
        }



    }
}
