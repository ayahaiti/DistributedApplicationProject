import gameFrames.GameInitialization;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import service.IGameRemote;


public class ClientRMI {

	public static void main(String[] args) {
		try {
			IGameRemote stub = (IGameRemote)Naming.lookup("rmi://localhost:1099/Game");
			System.out.println(stub.toString());
			GameInitialization.runInitialGrids(stub);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
