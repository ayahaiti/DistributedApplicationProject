package metier.controller;

import interfaces.GameInitialization;
import interfaces.PlayGrid;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class RunGame {

    public static Game game = new Game();

    public static void createNewGrids(List<String> myShips, String player_name){
        PlayGrid playGrid = new PlayGrid(player_name, "new Game", myShips);
        game.grids.add(playGrid);
        playGrid.runPlayGrid(player_name, myShips);
        playGrid.fireButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String targetButton = playGrid.jTextField.getText();
                game.fire(playGrid, targetButton, player_name);
            }
        });
    }


    public static void main(String[] args) {
        GameInitialization.runInitialGrids();
    }
}
