package services;

import metier.controller.Game;
import metier.controller.Initialization;
import metier.controller.RunGameServer;

import javax.swing.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

public class IGameImpl extends UnicastRemoteObject implements IGame {

    Initialization init = new Initialization();

    public IGameImpl() throws RemoteException {
    }

    @Override
    public boolean checkFields(List<String> fieldsInformation) {
        return init.checkFields(fieldsInformation);
    }

    @Override
    public boolean respectLocationFormat(String location) {
        return init.respectLocationFormat(location);
    }

    @Override
    public boolean validateLocationFormat(List<String> shipsInfo) {
        return init.validateLocationFormat(shipsInfo);
    }

    @Override
    public boolean validateLocationsOfShips(List<String> shipsInfo) {
        return init.validateLocationsOfShips(shipsInfo);
    }

    @Override
    public List<String> getButtonsAccordingToOrientation(int i, String startButton, String orientation) {
        return init.getButtonsAccordingToOrientation(i, startButton, orientation);
    }

    @Override
    public List<String> getShipsButtons(List<String> shipsInfo) {
        return init.getShipsButtons(shipsInfo);
    }

    @Override
    public boolean areLocationsPossible(List<String> shipsInfo) {
        return init.areLocationsPossible(shipsInfo);
    }

    @Override
    public void setButton(JButton jButton, String color) {
        init.setButton(jButton, color);
    }

    @Override
    public void findAndSetButtonOfCoordinates(JButton[][] b, int column, int line, String color) {
        init.findAndSetButtonOfCoordinates(b, column, line, color);
    }

    @Override
    public void createNewGrids(List<String> myShips, String player_name) {
        RunGameServer.createNewGrids(myShips, player_name);
    }

    @Override
    public void addNewPlayer(String player_name, List<String> playerShips) {
        Game.addNewPlayer(player_name, playerShips);
    }
}
