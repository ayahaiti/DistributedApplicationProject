package metier.controller;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import interfaces.PlayGrid;

public class RunGame {
	
	 public static Game game = new Game();

	    public static void createNewGrids(List<String> myShips, final String player_name){
	        final PlayGrid playGrid = new PlayGrid(player_name, "new Game", myShips);
	        game.grids.add(playGrid);
	        playGrid.runPlayGrid(player_name, myShips);
	        playGrid.fireButton.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	if(Game.numPlayersReached != 2){
	            		Game.grids.clear();
	            		Game.players.clear();
	            		Game.numPlayersReached = 0;
	            		playGrid.error.setText("SORRY! The other player has left the game!");
	            		playGrid.fireButton.setEnabled(false);
	            	}
	            	if(Game.grids.size() < 2 && Game.numPlayersReached == 2){
	            		playGrid.error.setText("Please wait for the other player to join the game!");
	            	}
	            	if(Game.grids.size() == 2 && Game.numPlayersReached == 2){
	            		String targetButton = playGrid.jTextField.getText();
	            		game.fire(playGrid, targetButton, player_name);
	            	}
	            }
	        });
	    }
}
