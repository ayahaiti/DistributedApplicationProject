package rmiclient;

import rmiclient.services.IGame;

import java.rmi.Naming;

public class GameClient {



}
