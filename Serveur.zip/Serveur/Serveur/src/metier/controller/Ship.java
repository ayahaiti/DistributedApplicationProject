package metier.controller;

public class Ship {
}
