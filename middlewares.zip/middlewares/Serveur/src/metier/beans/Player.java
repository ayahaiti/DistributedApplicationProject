package metier.beans;

import java.util.ArrayList;
import java.util.List;

public class Player {
	 private String player_name;
	    private List<String> ships ;

	    private List<String> locationsHit = new ArrayList<>();
	    private List<String> locationsMissed = new ArrayList<>();

	    private int enemyShipsEarned ;

	    private boolean winner = false;

	    public Player(String player_id, List<String> ships) {
	        this.player_name = player_id;
	        this.ships = ships;
	    }

	    public List<String> getShips() {
	        return this.ships;
	    }

	    public void setShips(List<String> ships) {
	        this.ships = ships;
	    }

	    public String getPlayer_name() {
	        return this.player_name;
	    }

	    public void setPlayer_name(String player_name) {
	        this.player_name = player_name;
	    }

	    public int getEnemyShipsEarned() {
	        return this.enemyShipsEarned;
	    }

	    public void setEnemyShipsEarned(int enemyShipsEarned) {
	        this.enemyShipsEarned = enemyShipsEarned;
	    }

	    public List<String> getLocationsHit() {
	        return locationsHit;
	    }

	    public void setLocationsHit(List<String> locationsHit) {
	        this.locationsHit = locationsHit;
	    }

	    public List<String> getLocationsMissed() {
	        return locationsMissed;
	    }

	    public void setLocationsMissed(List<String> locationsMissed) {
	        this.locationsMissed = locationsMissed;
	    }

	    public boolean isWinner() {
	        return this.winner;
	    }

	    public void setWinner(boolean winner) {
	        this.winner = winner;
	    }


}
