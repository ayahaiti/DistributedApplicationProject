package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import javax.swing.JButton;

public interface IGameRemote extends Remote{
	
	public boolean checkFields(List<String> fieldsInformation) throws RemoteException;
    public boolean respectLocationFormat(String location) throws RemoteException;
    public boolean validateLocationFormat(List<String> shipsInfo) throws RemoteException;
    public boolean validateLocationsOfShips(List<String> shipsInfo) throws RemoteException;
    public List<String> getButtonsAccordingToOrientation(int i, String startButton, String orientation) throws RemoteException;
    public List<String> getShipsButtons(List<String> shipsInfo) throws RemoteException;
    public boolean areLocationsPossible(List<String> shipsInfo) throws RemoteException;
    public void setButton(JButton jButton, String color) throws RemoteException;
    public void findAndSetButtonOfCoordinates(JButton b[][], int column, int line, String color) throws RemoteException;
    public void createNewGrids(List<String> myShips, String player_name) throws RemoteException;
    public void addNewPlayer(String player_name, List<String> playerShips) throws RemoteException;

}
