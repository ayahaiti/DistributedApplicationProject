package serveur;

import services.IGameImpl;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class ServeurRMI {

    public static void main(String[] args) {
        try{
            //Démarrage de l'annuaire
            LocateRegistry.createRegistry(1099);
            //création de l'objet distant
            IGameImpl iGame = new IGameImpl();

            System.setProperty("java.security.policy","src/security.policy");

            System.out.println(iGame.toString());
            Naming.rebind("rmi://localhost:1099/Game", iGame);

            System.out.println("Serveur lancé");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
