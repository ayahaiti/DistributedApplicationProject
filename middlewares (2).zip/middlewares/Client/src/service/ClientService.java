package service;




import gameFrames.GameInitialization;

import java.util.ArrayList;
import java.util.List;


public class ClientService {
	
	
	public List<Integer> plyersIDs = new ArrayList<Integer>(){{add(1); add(2);}};
	
	public ClientService() {
	}
	
	public int getPlayersID(){
		int playerID = plyersIDs.get(0);
		plyersIDs.remove(playerID);
		return playerID;
	}
	
 
	
}
