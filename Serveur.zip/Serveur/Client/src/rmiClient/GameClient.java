package rmiClient;

import java.rmi.Naming;

public class GameClient {

    public static void main(String[] args) {
        try{
            IGame stub = (IGame) Naming.lookup("rmi://localhost:1099/Game")
        }catch (Exception e){

        }
    }

}
