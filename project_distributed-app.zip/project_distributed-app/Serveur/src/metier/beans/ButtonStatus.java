package metier.beans;

import java.util.List;

public class ButtonStatus {

    private List<String> hitBy;
    private List<String> missedBy;
    private int hits ;
    private int misses ;

    public ButtonStatus() {
    }

    public ButtonStatus(List<String> hitBy, List<String> missedBy, int hits, int misses, int ships) {
        this.hitBy = hitBy;
        this.missedBy = missedBy;
        this.hits = hits;
        this.misses = misses;
    }

    public int getHits() {
        return hits;
    }

    public void setHits(int hits) {
        this.hits = hits;
    }

    public int getMisses() {
        return misses;
    }

    public void setMisses(int misses) {
        this.misses = misses;
    }

    public List<String> getHitBy() {
        return hitBy;
    }

    public void setHitBy(List<String> hitBy) {
        this.hitBy = hitBy;
    }

    public List<String> getMissedBy() {
        return missedBy;
    }

    public void setMissedBy(List<String> missedBy) {
        this.missedBy = missedBy;
    }

    @Override
    public String toString() {
        return "ButtonStatus{" +
                "hitBy=" + hitBy +
                ", missedBy=" + missedBy +
                ", hits=" + hits +
                ", misses=" + misses +
                '}';
    }
}
