public class test {

    //1- Il faut obtenir la référence de l'objet distant
    //2- Appeler les méthodes que l'on veu à partir de cette référence

    //Comment?
    //En utilisant deux classes: stub & skeleton générées avec l'outil rmi

    //Le stub et skeleton?
    // stub=>côté_client    skeleton=>côté_serveur

    //Que font ces deux classes?
    //Elles se chargent d'assurer tous les mécanismes d'appel, de communication, d'éxécution, de renvoi et de réception du résultat

    /*Les étapes de création de l'objet distant pour un appel à distance?

    1-cote_serveur
        A* La création d'une interface qui contient les méthodes à appeler
        B* L'implémentation de cet interface
        C* L'écriture d'une classe qui instanciera "L'objet" et l'enregistrera en lui affectant un nom dans le registre de noms RMI
        en trois étapes(la MEP d'un security Manager dédié + L'instanciation d'un objet de la classe distante + l'enregistrement de la classe dans le registre de noms RMI)

    2-cote_client
        A*Obtenir la référence de l'objet distant à partir de son nom
        B*L'appel de la méthode souhaitée

    3-Générer les classes stub et skeleton
        En Exécutant le programme rmic avec le fichier source de l'objet distant

     */

    /*
    Côté_serveur:

     */

    /*
    Côté_client:

     */


}
