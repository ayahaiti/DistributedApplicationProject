package cote_serveur;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


//Cette classe doit obligatoirement hériter de UnicastRemoteObject, Pourquoi?
// UnicastRemoteObject contient les différents traitements élémentaires pour un objet distant.
// L'appel de ces traitement élémentaires par le stub du client est unique.
// => le stub ne peut obtenir qu'une seule référence sur un objet distant héritant de UnicastRemoteObject.

public class InformationImpl extends UnicastRemoteObject implements Information {

    private static final long serialVersionUID = 2674880711467464646L;

    protected InformationImpl() throws RemoteException {
        super();
    }

    @Override
    public String getInformation() throws RemoteException {
        System.out.println("Invocation de la méthode getInformation()");
        return "bonjour";
    }
}
