import gameFrames.ClientsLimit;
import gameFrames.GameInitialization;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import service.ClientService;
import service.IGameRemote;


public class ClientRMI {

	// one client at a time
	public synchronized static void main(String[] args) {
		try {
			IGameRemote stub = (IGameRemote)Naming.lookup("rmi://localhost:1099/Game");
			System.out.println(stub.toString());
			int numberOfClients = stub.getNumOfPlayers();
			if(numberOfClients < 2){
				stub.addPlayer();
				System.out.println(stub.getNumOfPlayers());
				GameInitialization.createNewClient(stub);
			}
			if (numberOfClients == 2) {
				ClientsLimit cLimit = new ClientsLimit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
