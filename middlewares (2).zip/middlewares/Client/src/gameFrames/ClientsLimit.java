package gameFrames;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ClientsLimit extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6405558759914502012L;
	

	public ClientsLimit(){
		super("TwoPlayersOnly");
		JPanel limitPanel = new JPanel(new BorderLayout());
		JPanel labelPanel = new JPanel();
		JPanel buttonPanel = new JPanel();
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
        okButton.setPreferredSize(new Dimension(70,30));
		okButton.setBackground(Color.black);
		okButton.setForeground(Color.white);
		JLabel tellLimits = new JLabel("Number of Clients' been reached, try again at the end of this running game!");
		labelPanel.add(tellLimits);
		buttonPanel.add(okButton);
		limitPanel.add(labelPanel, BorderLayout.NORTH);
		limitPanel.add(buttonPanel, BorderLayout.SOUTH);
		this.getContentPane().add(limitPanel);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setSize(500, 100);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}
	
	
	
	
}

