package serveur;

import services.IGameImpl;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class ServeurRMI {

    public static void main(String[] args) {
        try{
            LocateRegistry.createRegistry(1099);

            IGameImpl iGame = new IGameImpl();
            System.out.println(iGame.toString());
            Naming.rebind("rmi://localhost:1099/Game", iGame);
        }catch (RemoteException | MalformedURLException e){
            e.printStackTrace();
        }
    }

}
