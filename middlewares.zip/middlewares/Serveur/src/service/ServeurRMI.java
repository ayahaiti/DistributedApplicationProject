package service;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class ServeurRMI {

	public static void main(String[] args) {
		try{
            LocateRegistry.createRegistry(1099);
            IGameServiceImpl iGame = new IGameServiceImpl();
            System.out.println(iGame.toString());
            Naming.rebind("rmi://localhost:1099/Game", iGame);
        }catch (Exception e){
            e.printStackTrace();
        }
	}
}
