package gameFrames;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import service.IGameRemote;
import styling.HintTextField;

public class GameInitialization extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7406667367491560215L;



	public JButton b[][] = new JButton[11][11];
	

	public JButton fireButton;
	public JButton playButton;

	public String player_name;
	public List<String> shipsInfo = new ArrayList<>();
	public List<String> myShips = new ArrayList<>();


	public JLabel error;

	public JLabel errorJustification;

	public JPanel mainPanel ;
	public JPanel carrierPanel ;
	public JPanel battleshipPanel ;
	public JPanel cruiserPanel ;
	public JPanel submarinesPanel ;
	public JPanel destroyerPanel ;

	public JRadioButton carrierCheckBoxHorizontal;
	public JRadioButton battleCheckBoxHorizontal;
	public JRadioButton cruiserCheckBoxHorizontal;
	public JRadioButton submarineCheckBoxHorizontal;
	public JRadioButton destroyerCheckBoxHorizontal;

	public JRadioButton carrierCheckBoxVertical;
	public JRadioButton battleCheckBoxVertical;
	public JRadioButton cruiserCheckBoxVertical;
	public JRadioButton submarineCheckBoxVertical;
	public JRadioButton destroyerCheckBoxVertical;



	public JLabel carrierShip    = new JLabel("Carrier (5 squares)         :");
	public JLabel battleShip     = new JLabel("BattleShip (4 squares)   :");
	public JLabel cruiserShip    = new JLabel("Cruiser (3 squares)       :");
	public JLabel submarinesShip = new JLabel("Submarines (3 squares):");
	public JLabel destroyerShip  = new JLabel("Destroyer: (2 squares)   :");

	public ButtonGroup carrierButton ;
	public ButtonGroup battleshipButton;
	public ButtonGroup cruiserButton ;
	public ButtonGroup submarinesButton ;
	public ButtonGroup destroyerButton;
	public JLabel title_label ;
	public JPanel gridPanel ;
	public JPanel firePanel;
	public JPanel playPanel;
	public BoxLayout boxLayout;
	

	public void addSetCarrierShipPanel(JPanel firePanel,JPanel carrierPanel, ButtonGroup carrierButton) {
		carrierButton.add(carrierCheckBoxHorizontal);
		carrierButton.add(carrierCheckBoxVertical);
		carrierPanel.add(carrierShip);
		carrierPanel.add(carrierCheckBoxHorizontal);
		carrierPanel.add(carrierCheckBoxVertical);
		firePanel.add(carrierPanel);
	}

	public void addSetBattleShipPanel(JPanel firePanel, JPanel battleshipPanel, ButtonGroup battleshipButton){
		battleshipButton.add(battleCheckBoxHorizontal);
		battleshipButton.add(battleCheckBoxVertical);
		battleshipPanel.add(battleShip);
		battleshipPanel.add(battleCheckBoxHorizontal);
		battleshipPanel.add(battleCheckBoxVertical);
		firePanel.add(battleshipPanel);
	}

	public void addSetCruiserShipPanel(JPanel firePanel, JPanel cruiserPanel, ButtonGroup cruiserButton){
		cruiserButton.add(cruiserCheckBoxHorizontal);
		cruiserButton.add(cruiserCheckBoxVertical);
		cruiserPanel.add(cruiserShip);
		cruiserPanel.add(cruiserCheckBoxHorizontal);
		cruiserPanel.add(cruiserCheckBoxVertical);
		firePanel.add(cruiserPanel);
	}

	public void addSetSubmarinesShipPanel(JPanel firePanel, JPanel submarinesPanel, ButtonGroup submarinesButton){
		submarinesButton.add(submarineCheckBoxHorizontal);
		submarinesButton.add(submarineCheckBoxVertical);
		submarinesPanel.add(submarinesShip);
		submarinesPanel.add(submarineCheckBoxHorizontal);
		submarinesPanel.add(submarineCheckBoxVertical);
		firePanel.add(submarinesPanel);
	}

	public void addSetDestroyerShipPanel(JPanel firePanel, JPanel destroyerPanel, ButtonGroup destroyerButton){
		destroyerButton.add(destroyerCheckBoxHorizontal);
		destroyerButton.add(destroyerCheckBoxVertical);
		destroyerPanel.add(destroyerShip);
		destroyerPanel.add(destroyerCheckBoxHorizontal);
		destroyerPanel.add(destroyerCheckBoxVertical);
		firePanel.add(destroyerPanel);
	}

	public void addSquaresLabels(JPanel gridPanel, JButton b[][]){
		int line = 1;
		char column = 'A';
		char column_ = 'A';
		for (int i = 0; i < 11; i++) {
			for (int j = 0; j < 11; j++) {
				if(i==0 || j==0){
					b[i][j] = new JButton();
					if (i != 0){
						b[i][j].setText(String.valueOf(line));
						line++;
					}
					if (j != 0){
						b[i][j].setText(String.valueOf(column));
						column++;
					}
					b[i][j].setBackground(Color.WHITE);
					gridPanel.add(b[i][j]);
				}
				else {
					b[i][j] = new JButton();
					String the_line = Integer.toString(line-1);
					String the_column = String.valueOf(column_++);
					b[i][j].setName( the_column + the_line );
					b[i][j].setBackground(Color.LIGHT_GRAY);
					gridPanel.add(b[i][j]);
				}
			}
			column_ = 'A';
		}
	}
	public void addSetLocationInfo(JPanel jPanels[]){
		for(int i=0; i<5; i++){
			JTextField location = new HintTextField("ex: A1");
			location.setPreferredSize(new Dimension(40,20));
			jPanels[i].add(new JLabel("     Location "));
			jPanels[i].add(location);
		}
	}

	public void addSetFirePanel(JLabel title_label, JPanel firePanel, JPanel carrierPanel, JPanel cruiserPanel
			, JPanel battleshipPanel, JPanel submarinesPanel, JPanel destroyerPanel, BoxLayout boxLayout,
			JPanel jPanels[], JButton fireButton, ButtonGroup carrierButton, ButtonGroup battleButton,
			ButtonGroup cruiserButton, ButtonGroup subMarinesButton, ButtonGroup destroyerButton){
		firePanel.add(title_label);
		firePanel.setLayout(boxLayout);
		fireButton.setPreferredSize(new Dimension(70,30));
		fireButton.setBackground(Color.BLUE);
		fireButton.setForeground(Color.WHITE);
		addSetCarrierShipPanel(firePanel,carrierPanel, carrierButton);
		addSetBattleShipPanel(firePanel, battleshipPanel, battleButton);
		addSetCruiserShipPanel(firePanel, cruiserPanel, cruiserButton);
		addSetSubmarinesShipPanel(firePanel, submarinesPanel, subMarinesButton);
		addSetDestroyerShipPanel(firePanel, destroyerPanel, destroyerButton);
		addSetLocationInfo(jPanels);
		firePanel.add(fireButton);
		firePanel.add(error);
	}

	public void setMainPanel(JPanel firePanel, JPanel gridPanel, JPanel playPanel, JPanel mainPanel, JButton playButton){
		gridPanel.setPreferredSize(new Dimension(550,400));
		playButton.setBackground(Color.white);
		playPanel.add(errorJustification, BorderLayout.NORTH);
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(playButton);
		playPanel.add(buttonPanel, BorderLayout.SOUTH);
		mainPanel.add(firePanel, BorderLayout.NORTH);
		mainPanel.add(gridPanel, BorderLayout.CENTER);
		mainPanel.add(playPanel, BorderLayout.SOUTH);
	}

	public GameInitialization(String title, IGameRemote stub)
	{
		super(title);
		carrierCheckBoxHorizontal = new JRadioButton("horizontal");
		battleCheckBoxHorizontal = new JRadioButton("horizontal");
		cruiserCheckBoxHorizontal = new JRadioButton("horizontal");
		submarineCheckBoxHorizontal = new JRadioButton("horizontal");
		destroyerCheckBoxHorizontal = new JRadioButton("horizontal");
		carrierCheckBoxVertical = new JRadioButton("vertical");
		battleCheckBoxVertical = new JRadioButton("vertical");
		cruiserCheckBoxVertical = new JRadioButton("vertical");
		submarineCheckBoxVertical = new JRadioButton("vertical");
		destroyerCheckBoxVertical = new JRadioButton("vertical");
		shipsInfo = new ArrayList<>();
		fireButton = new JButton("ADD");
		playButton = new JButton("Play");
		carrierButton = new ButtonGroup();
		battleshipButton = new ButtonGroup();
		cruiserButton = new ButtonGroup();
		submarinesButton = new ButtonGroup();
		destroyerButton = new ButtonGroup();
		error = new JLabel("");
		errorJustification = new JLabel("");
		title_label = new JLabel("Choose your ships' locations");
		mainPanel = new JPanel(new BorderLayout());
		gridPanel = new JPanel(new GridLayout(11, 11));
		firePanel = new JPanel();
		playPanel = new JPanel(new BorderLayout());
		boxLayout = new BoxLayout(firePanel, BoxLayout.Y_AXIS);
		carrierPanel = new JPanel();
		battleshipPanel =new JPanel();
		cruiserPanel = new JPanel();
		submarinesPanel = new JPanel();
		destroyerPanel = new JPanel();
		JPanel jPanels[] = {carrierPanel, battleshipPanel, cruiserPanel, submarinesPanel, destroyerPanel };
		List<String> list = getShipsInformation(jPanels);
		for(int i=0; i<list.size(); i++){
			this.shipsInfo.add(list.get(i));
		}
		addSetFirePanel(title_label, firePanel, carrierPanel, cruiserPanel
				, battleshipPanel, submarinesPanel, destroyerPanel, boxLayout, jPanels,
				fireButton, carrierButton, battleshipButton, cruiserButton, submarinesButton, destroyerButton);
		addSquaresLabels(gridPanel, this.b);
		setMainPanel(firePanel, gridPanel, playPanel, mainPanel, playButton);
		getContentPane().add(mainPanel);
		addsShipsToGrid(this, stub);
	}

	public static List<String> getShipsInformation(JPanel jPanels[]){
		List<String> shipsInformation = new ArrayList<>();
		for(int i=0; i<5; i++){
			Component[] components = jPanels[i].getComponents();
			for(Component comp : components){
				if(comp instanceof JTextField){
					shipsInformation.add(((HintTextField) comp).getText());
				}
				if(comp instanceof JRadioButton){
					JRadioButton radioButton = (JRadioButton) comp;
					if(radioButton.isSelected()) {
						shipsInformation.add(radioButton.getText());
					}
				}
			}
		}
		return shipsInformation;
	}


	public void addsShipsToGrid(final GameInitialization s, final IGameRemote stub){
		//send and receive buttons to mark as my ships in a list
		s.fireButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getActionCommand().equals("ADD")){
					//get ships information from Front-End
					JPanel jPanels[] = {s.carrierPanel, s.battleshipPanel, s.cruiserPanel, s.submarinesPanel, s.destroyerPanel};
					s.shipsInfo = getShipsInformation(jPanels);
					//call to check if all the fields are completed
					boolean fieldComplete;
					try {
						fieldComplete = stub.checkFields(s.shipsInfo);
						//validate locations input
						boolean validLocationFormat = stub.validateLocationFormat(s.shipsInfo);
						if( fieldComplete) {
							if (validLocationFormat) {
								//get complete buttons for ships from chosen locations
								s.myShips = stub.getShipsButtons(s.shipsInfo);
								//call and validate ships locations that have been chosen
								boolean validLocationChoices = stub.validateLocationsOfShips(s.myShips);
								boolean possibleLocations = stub.areLocationsPossible(s.shipsInfo);
								if (validLocationChoices) {
									if(possibleLocations) {
										for (int i = 0; i < s.myShips.size(); i++) {
											//find button's name that is equal to myShips.get(i)
											for (int x = 1; x < 11; x++) {
												for (int y = 1; y < 11; y++) {
													if (s.b[x][y].getName().equals(s.myShips.get(i))) {
														s.b[x][y].setBackground(Color.cyan);
													}
												}
											}
										}
										s.error.setText("Valid Choices!");
										s.error.setForeground(Color.GREEN);
										s.fireButton.setEnabled(false);
									}
									else {
										s.error.setText("Not Possible Locations");
										s.error.setForeground(Color.RED);
									}
								} else {
									s.error.setText("Interconnected Locations");
									s.error.setForeground(Color.RED);
								}
							}
							else {
								s.error.setText("NonValid location(s) Format");
								s.error.setForeground(Color.RED);
							}
						}
						else{
							s.error.setText("At least one field is empty! Please complete all the fields.");
							s.error.setForeground(Color.RED);
						}
					}catch(Exception g){
						g.printStackTrace();
					}
				}
			}
		});
		s.playButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getActionCommand().equals("Play")){
					int h = 0;
					try {
						h = stub.getNumOfPlayers();
					} catch (RemoteException e2) {
						e2.printStackTrace();
					}
					if(s.error.getText().equals("Valid Choices!") && h != -1) {
						try {
							if(stub.getNumOfPlayers() == 2){
								s.setVisible(false);
								s.dispose();
								stub.createNewGrids(s.myShips, s.player_name);
							}
							if(stub.getNumOfPlayers() == 1 ){
								s.errorJustification.setText("Please wait for the second Player to Join!");
								s.errorJustification.setForeground(Color.BLUE);
							}
							if(stub.getNumOfPlayers() == 0){
								s.errorJustification.setText("Sorry! The other player has left the Game!");
								s.errorJustification.setForeground(Color.RED);
								s.playButton.setEnabled(false);
							}
						} catch (RemoteException e1) {
							e1.printStackTrace();
						}
					}
					if(h == -1) {
						s.errorJustification.setForeground(Color.RED);
						s.errorJustification.setText("Sorry! The Other Player has left the Game!");
						s.playButton.setEnabled(false);
						
					}
				}
			}
		});
	}

	public void runInitialGrids(final IGameRemote stub) {
		//Client's Thread
		// if one GameInitialization_jframe is closed : the other closes too and numPlayers is back to 0
		// if one PlayGrid_jframe is closed :  numPlayers is back to 0
		// server should always stay running
		int clientStatus = 0;
		try {
			clientStatus = stub.getNumOfPlayers();
			this.player_name = "player" + clientStatus;
			this.setSize(600, 700);
			if(this.player_name.equals("player1")){
				this.setLocation(750,0);
			}
			else {
				this.setLocation(0,0);
			}
			this.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent arg0) {
					try {
						stub.setToInitialPlayers();
						int b = stub.getClosedWindows();
						stub.setClosedWindows(b+1);
				} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
			});
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void createNewClient(final IGameRemote stub) {
		GameInitialization gInitialization = new GameInitialization("Player", stub);
		gInitialization.runInitialGrids(stub);
	}

}
