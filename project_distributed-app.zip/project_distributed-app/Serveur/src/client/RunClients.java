package client;

import java.rmi.Naming;

public class RunClients {

    public static void main(String[] args) {
        try{
            IGame stub = (IGame) Naming.lookup("rmi://localhost:1099/Game");

            System.out.println("Please work");
            //GameInitialization.runInitialGrids(stub);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
