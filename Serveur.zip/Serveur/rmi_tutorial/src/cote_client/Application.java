package cote_client;

import cote_serveur.Information;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public class Application {


    public static void main(String[] args) {
        System.out.println("Lancement du client");

        //Il est préférable de prévoir le nom du serveur sous forme de paramètre de l'application
        try{
            Information r = (Information) Naming.lookup("rmi://192.168.1.73/Classeinstanciation");
            String s = r.getInformation();
            System.out.println("chaine renvoyee = " + s);

        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("Fin du client");
    }

}
