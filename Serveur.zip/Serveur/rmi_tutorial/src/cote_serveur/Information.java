package cote_serveur;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Information extends Remote {

    //Chaque méthode appelée à distance doit déclarer qu'elle est en mesure de lever l'exception java.rmi.RemoteException
    // car la communication entre le client et le serveur pour l'invocation de la méthode peut échouer pour diverses raisons (rupture de liaison, ...)

    public String getInformation() throws RemoteException;

}
