package services;

import metier.controller.Initialization;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class IGameImpl extends UnicastRemoteObject implements IGame {

    public IGameImpl() throws RemoteException {
        super();
    }

}
