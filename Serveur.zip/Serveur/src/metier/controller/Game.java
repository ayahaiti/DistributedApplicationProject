package metier.controller;

import interfaces.PlayGrid;
import metier.beans.Grid;
import metier.beans.Player;

import java.util.ArrayList;
import java.util.List;

public class Game {

    public static List<Player> players = new ArrayList<>();
    public static List<PlayGrid> grids= new ArrayList<>();
    private static Grid sharedGrid = new Grid();
    private Initialization initialization = new Initialization();

    public Game(){
    }

    public static void addNewPlayer(String player_name, List<String> playerShips){
        Player player = new Player(player_name, playerShips);
        players.add(player);
    }

    public static String findOutHitOrMiss(String targetButton, String player_name){
        String color = "";
        boolean a = players.get(0).getPlayer_name().equals(player_name);
        boolean b = players.get(1).getShips().contains(targetButton);
        if((players.get(0).getPlayer_name().equals(player_name) && players.get(1).getShips().contains(targetButton) && !players.get(0).getLocationsHit().contains(targetButton))
        || (players.get(1).getPlayer_name().equals(player_name) && players.get(0).getShips().contains(targetButton))&& !players.get(1).getLocationsHit().contains(targetButton))
        {
            color = "red";
        }
        if((players.get(0).getPlayer_name().equals(player_name) && !players.get(1).getShips().contains(targetButton))
        || (players.get(1).getPlayer_name().equals(player_name) && !players.get(0).getShips().contains(targetButton)))
        {
            color = "black";
        }
        return color;
    }

    public Player setOtherPlayer(List<Player> players, String player_name){
        if(players.get(0).getPlayer_name().equals(player_name)){
            return players.get(1);
        }
        else{
            return players.get(0);
        }
    }
    public PlayGrid setOtherGrid(List<PlayGrid> playGrids, String player_name){
        if(playGrids.get(0).owner.equals(player_name)){
            return playGrids.get(1);
        }
        else{
            return playGrids.get(0);
        }
    }

    public void fire(PlayGrid p,String targetButton, String player_name) {
        p.error.setText("");
        for(int i=0; i<this.players.size(); i++) {
                if (this.players.get(i).getEnemyShipsEarned() != 17 && this.players.get(i).getPlayer_name().equals(player_name)) {
                    boolean inputFormatValid = initialization.respectLocationFormat(targetButton);
                    if (inputFormatValid == false) {
                        p.error.setText("NonValid Location(s) Format");
                    } else {
                        String color = findOutHitOrMiss(targetButton, player_name);
                        initialization.addHitOrMissAction(p.b, targetButton, color);
                        if (color.equals("red")) {
                            this.players.get(i).getLocationsHit().add(targetButton);
                            this.players.get(i).setEnemyShipsEarned(this.players.get(i).getEnemyShipsEarned() + 1);
                        } else {
                            List<String> liste = this.players.get(i).getLocationsMissed();
                            liste.add(targetButton);
                            this.players.get(i).setLocationsMissed(liste);
                        }
                    }
                }
            if(this.players.get(i).getEnemyShipsEarned() == 17 && this.players.get(i).getPlayer_name().equals(player_name)){
                this.players.get(i).setWinner(true);
                setOtherPlayer(this.players, player_name).setWinner(false);
                setOtherGrid(this.grids, player_name).error.setText("YOU LOST");
                p.error.setText("YOU WON");

            }
            if(players.get(0).isWinner() || players.get(1).isWinner()){
                this.grids.get(0).fireButton.setEnabled(false);
                this.grids.get(0).jTextField.setText("");
                this.grids.get(1).fireButton.setEnabled(false);
                this.grids.get(1).jTextField.setText("");
            }
        }
    }
}
