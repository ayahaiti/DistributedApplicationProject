package services;

import metier.controller.Initialization;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class IGameImpl extends UnicastRemoteObject implements IGame {

    private Initialization init;

    public IGameImpl() throws RemoteException {
        super();
        init = new Initialization();
    }

    @Override
    public String getSomething(String a) throws RemoteException {
        String j = init.getSomething(a);
        return j;
    }
}
