package service;

import java.awt.Window;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

import javax.swing.JButton;

import metier.controller.Game;
import metier.controller.GameInitialization;
import metier.controller.Initialization;
import metier.controller.RunGame;

public class IGameServiceImpl extends UnicastRemoteObject implements IGameRemote{

	protected IGameServiceImpl() throws RemoteException {
		super();
	}


	Initialization init = new Initialization();

	    
	    @Override
	    public boolean checkFields(List<String> fieldsInformation) {
	        return init.checkFields(fieldsInformation);
	    }

	    @Override
	    public boolean respectLocationFormat(String location) {
	        return init.respectLocationFormat(location);
	    }

	    @Override
	    public boolean validateLocationFormat(List<String> shipsInfo) {
	        return init.validateLocationFormat(shipsInfo);
	    }

	    @Override
	    public boolean validateLocationsOfShips(List<String> shipsInfo) {
	        return init.validateLocationsOfShips(shipsInfo);
	    }

	    @Override
	    public List<String> getButtonsAccordingToOrientation(int i, String startButton, String orientation) {
	        return init.getButtonsAccordingToOrientation(i, startButton, orientation);
	    }

	    @Override
	    public List<String> getShipsButtons(List<String> shipsInfo) {
	        return init.getShipsButtons(shipsInfo);
	    }

	    @Override
	    public boolean areLocationsPossible(List<String> shipsInfo) {
	        return init.areLocationsPossible(shipsInfo);
	    }

	    @Override
	    public void setButton(JButton jButton, String color) {
	        init.setButton(jButton, color);
	    }

	    @Override
	    public void findAndSetButtonOfCoordinates(JButton[][] b, int column, int line, String color) {
	        init.findAndSetButtonOfCoordinates(b, column, line, color);
	    }

	    @Override
	    public void createNewGrids(List<String> myShips, String player_name) {
	        RunGame.createNewGrids(myShips, player_name);
	    }

	    @Override
	    public void addNewPlayer(String player_name, List<String> playerShips) {
	        Game.addNewPlayer(player_name, playerShips);
	    }

		@Override
		public void addPlayer() throws RemoteException {
			Game.addPlayer();
		}

		@Override
		public int getNumOfPlayers() throws RemoteException {
			return Game.numPlayersReached;
		}

		@Override
		public void setToInitialPlayers() throws RemoteException {
			Game.setToInitialPlayers();
		}

		@Override
		public void setPlayerGone() throws RemoteException {
			Game.setPlayerHasGone();
			
		}

		@Override
		public boolean shipsAreAdded() throws RemoteException {
			return Game.shipsAreAdded();
		}

}
