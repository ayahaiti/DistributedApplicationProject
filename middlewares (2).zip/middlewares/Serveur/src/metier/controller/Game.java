package metier.controller;

import interfaces.PlayGrid;


import java.util.ArrayList;
import java.util.List;

import metier.beans.ButtonStatus;
import metier.beans.Player;

public class Game {
	

    public static List<Player> players = new ArrayList<>();
    public static List<PlayGrid> grids= new ArrayList<>();
    public static int numPlayersReached ;
    public boolean shipsAreAdded;

    //This is the shared variable that carries out the game status (the common grid)
    // It has to be accessed every time a player hits the "FIRE" button => he/they ask this grid to be updated
    private static ButtonStatus sharedGrid [][] = new ButtonStatus[11][11];

    private Initialization initialization = new Initialization();

    public Game(){
        for (int i = 1; i < sharedGrid.length; i++) {
            for (int j = 1; j < sharedGrid[0].length; j++) {
                this.sharedGrid[i][j] = new ButtonStatus(new ArrayList<String>(), new ArrayList<String>(), 0, 0, 0);
            }
        }

    }
    
    public static boolean shipsAreAdded(){
    	boolean added = true;
    	for(int h=0; h<players.size(); h++){
    		System.out.println(players.get(h).getShips().size());
    		if(players.get(h).getShips().size() < 17){
    			added = false;
    			System.out.println(added);
    		}
    	}
    	return added;
    }
    
    public static void addNewPlayer(String player_name, List<String> playerShips){
        Player player = new Player(player_name, playerShips);
        players.add(player);
    }

    public static String findOutHitOrMiss(String targetButton, String player_name){
        String color = "";
        boolean a = players.get(0).getPlayer_name().equals(player_name);
        boolean b = players.get(1).getShips().contains(targetButton);
        if((players.get(0).getPlayer_name().equals(player_name) && players.get(1).getShips().contains(targetButton) && !players.get(0).getLocationsHit().contains(targetButton))
        || (players.get(1).getPlayer_name().equals(player_name) && players.get(0).getShips().contains(targetButton))&& !players.get(1).getLocationsHit().contains(targetButton))
        {
            color = "red";
        }
        if((players.get(0).getPlayer_name().equals(player_name) && !players.get(1).getShips().contains(targetButton))
        || (players.get(1).getPlayer_name().equals(player_name) && !players.get(0).getShips().contains(targetButton)))
        {
            color = "black";
        }
        return color;
    }

    public Player setOtherPlayer(List<Player> players, String player_name){
        if(players.get(0).getPlayer_name().equals(player_name)){
            return players.get(1);
        }
        else{
            return players.get(0);
        }
    }
    public PlayGrid setOtherGrid(List<PlayGrid> playGrids, String player_name){
        if(playGrids.get(0).owner.equals(player_name)){
            return playGrids.get(1);
        }
        else{
            return playGrids.get(0);
        }
    }

    // This method has to be synchronized so that only one thread=one player can access it
    // because it's in this method where the shared variable is UPDATED
    public synchronized void addToSharedGrid(String player_name, String color, int line, int column){
        if(color.equals("red")){
            this.sharedGrid[line][column].setHits(this.sharedGrid[line][column].getHits() + 1);
            if(!this.sharedGrid[line][column].getHitBy().contains(player_name)) {
                this.sharedGrid[line][column].getHitBy().add(player_name);
            }
        }
        if (color.equals("black")){
            this.sharedGrid[line][column].setMisses(this.sharedGrid[line][column].getMisses() + 1);
            if(!this.sharedGrid[line][column].getMissedBy().contains(player_name)) {
                this.sharedGrid[line][column].getMissedBy().add(player_name);
            }
        }
    }

    public static int getLine(String location){
        String theButtonStart[] = location.split("");
        String number = "";
        if (location.length() > 2) {
            number = theButtonStart[1] + theButtonStart[2];
        } else {
            number = theButtonStart[1];
        }
        int newNumber = Integer.valueOf(number);
        return newNumber;
    }

    public static int getColumn(String location){
        String theButtonStart[] = location.split("");
        String letter = theButtonStart[0];
        int newLetter = (letter.charAt(0) & 31);
        return newLetter;
    }

    public static void showSharedGrid(ButtonStatus a[][]){
        for (int i = 1; i < a.length; i++) {
            for (int j = 1; j < a[0].length; j++) {
                System.out.print(a[i][j].toString() + "\t");
            }
            System.out.println("\t");
        }
    }

    public void fire(PlayGrid p, String targetButton, String player_name) {
        p.error.setText("");
        for(int i=0; i<this.players.size(); i++) {
                if (this.players.get(i).getEnemyShipsEarned() != 17 && this.players.get(i).getPlayer_name().equals(player_name)) {
                    boolean inputFormatValid = initialization.respectLocationFormat(targetButton);
                    if (inputFormatValid == false) {
                        p.error.setText("NonValid Location(s) Format");
                    } else {
                        String color = findOutHitOrMiss(targetButton, player_name);
                        int line = getLine(targetButton);
                        int column = getColumn(targetButton);
                        this.addToSharedGrid(player_name, color, line, column);
                        initialization.findAndSetButtonOfCoordinates(p.b,column, line, color);
                        if (color.equals("red")) {
                            this.players.get(i).getLocationsHit().add(targetButton);
                            this.players.get(i).setEnemyShipsEarned(this.players.get(i).getEnemyShipsEarned() + 1);
                        } else {
                            List<String> liste = this.players.get(i).getLocationsMissed();
                            liste.add(targetButton);
                            this.players.get(i).setLocationsMissed(liste);
                        }
                    }
                }
            if(this.players.get(i).getEnemyShipsEarned() == 17 && this.players.get(i).getPlayer_name().equals(player_name)){
                this.players.get(i).setWinner(true);
                setOtherPlayer(this.players, player_name).setWinner(false);
                setOtherGrid(this.grids, player_name).error.setText("YOU LOST");
                p.error.setText("YOU WON");
                showSharedGrid(this.sharedGrid);
                setToInitialPlayers();
            }
            if(this.players.get(0).isWinner() || this.players.get(1).isWinner()){
                this.grids.get(0).fireButton.setEnabled(false);
                this.grids.get(0).jTextField.setText("");
                this.grids.get(1).fireButton.setEnabled(false);
                this.grids.get(1).jTextField.setText("");
                for (int a = 1; a < sharedGrid.length; a++) {
                    for (int b = 1; b < sharedGrid[0].length; b++) {
                        this.sharedGrid[a][b] = new ButtonStatus(new ArrayList<String>(), new ArrayList<String>(), 0, 0, 0);
                    }
                }
                numPlayersReached = 0;
                players.clear();
                grids.clear();
            }
        }
    }

	public static synchronized void addPlayer() {
		numPlayersReached ++;
	}
	
	public static synchronized void setToInitialPlayers(){
		numPlayersReached = 0;
	}

	public static void setPlayerHasGone() {
		numPlayersReached = -1;
	}

}
